const arr = [3, 4, 1, 4, 4, 2, 0, 4, 2, 0];

const removeDuplicates = (arr) => {
  const newValues = [];
  const duplicates = {};

  for (const value of arr) {

    if (duplicates[value] === undefined) {

      newValues.push(value);

      duplicates[value] = true;
    }
  }

  return newValues;
}

console.log(removeDuplicates(arr));