const arr = [3, 4, 1, 4, 4, 2, 0, 4, 2, 0];

const SrchDuplicates = (arr) => {
  const duplicates = {};
  const result = [];

  for (let num of arr) {

    if (duplicates[num] === undefined) {

      duplicates[num] = false;

    } else if (duplicates[num] === false) {

      result.push(num);

      duplicates[num] = true;
    }
  }

  return result;
}



console.log(SrchDuplicates(arr));