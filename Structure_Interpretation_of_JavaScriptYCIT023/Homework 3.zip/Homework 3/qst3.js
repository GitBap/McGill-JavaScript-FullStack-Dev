function passwordVerification(password){
    var regex =/^(?=.*[a-z].*[a-z])(?=.*[A-Z].*[A-Z])(?=.*[#$%^&])[a-zA-Z0-9#$%^&]{8,}$/;
    return regex.test(password);
}

function passwordInput() {
    var password = document.getElementById("password").value;
    var output = document.getElementById("output");

    if (passwordVerification(password)) {
        output.textContent = "good password";
        output.style.color = "green";
    } else {
        output.textContent = "bad password";
        output.style.color = "red";
    }
} 


  


