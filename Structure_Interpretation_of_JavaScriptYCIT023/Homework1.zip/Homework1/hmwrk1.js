// Printing list of numbers from 0 to 25 //
for (let i = 0; i <= 25; i++){

    // if divisible by 3 && 5, print i and "fizzBuzz" //
    if (i % 3 === 0 && i % 5 === 0){
        console.log (i + "FizBuzz") ;

    // if divisible by 3, print i and "fizz"//
    } else if (i % 3 === 0){
        console.log(i + "Fizz");

    // if divisible by 5, print i and "Buzz"//
    } else if (i % 5 === 0){
        console.log(i + "Buzz");

    // prints other numbers
    } else {
        console.log(i);
    }

    
}