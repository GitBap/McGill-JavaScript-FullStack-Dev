/**
 * Get the second card in the given deck
 *
 * @param {Card[]} deck
 *
 * @returns {Card} the second card in the deck
 */
export function getSecondCard(deck) {
    const [, secondCard] = deck;
    return secondCard;
  }
  /**
   * Switch the position of the first two cards in the given deck
   *
   * @param {Card[]} deck
   *
   * @returns {Card[]} new deck with reordered cards
   */
  export function swapTopTwoCards(deck) {
    const [firstCard, secondCard, ...remainingCards] = deck;
    return [secondCard, firstCard, ...remainingCards];
  }
  /**
   * Put the top card of the given deck into a separate discard pile
   *
   * @param {Card[]} deck
   *
   * @returns {[Card, Card[]]} the top card of the given
   * deck and a new deck containing all the other cards
   */
  export function discardTopCard(deck) {
    const [firstCard, ...remainingCards] = deck;
    return [firstCard, remainingCards];
  }
  /** @type Card[] **/
  const FACE_CARDS = ['jack', 'queen', 'king'];
  /**
   * Insert face cards into the given deck
   *
   * @param {Card[]} deck
   *
   * @returns {Card[]} new deck where the second,
   * third, and fourth cards are the face cards
   */
  export function insertFaceCards(deck) {
    const [firstCard, ...remainingCards] = deck;
    return [firstCard, ...FACE_CARDS, ...remainingCards];
  }