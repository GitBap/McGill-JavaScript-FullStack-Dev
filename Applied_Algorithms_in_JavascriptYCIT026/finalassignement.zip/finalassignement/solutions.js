// Task1
// https://jasonjafari.notion.site/Frequency-Counter-eecdaa7e0ca84a96af0ec278719f07f6
export function areTowValuesAnagram(s1, s2) {
  function areTwoValuesAnagram(s1, s2) {
    const str1 = s1.replace(/[^0-9a-z]/gi, '').toLowerCase();
  const str2 = s2.replace(/[^0-9a-z]/gi, '').toLowerCase();
  const sortedStr1 = str1.split('').sort().join('');
  const sortedStr2 = str2.split('').sort().join('');

  return sortedStr1 === sortedStr2 ? "Anagram" : "Not Anagram";
  }

}

// Task2
// https://jasonjafari.notion.site/Multiple-Pointes-Contains-Duplicate-1acceaddc37746acaf69ae7d84de42ed
export function containsDuplicate(nums) {
  let set = new Set(); 
  for (let num of nums) { 
    if (set.has(num)) return true; 
    set.add(num); 
  }
  return false;
}

// Task3
// https://jasonjafari.notion.site/Sliding-Window-maxSubarraySum-b400bee7645a4a48b22d29a848dc5f68
export function maxSubarraySum(arr, num) {
  if (num > arr.length) {
    return null;
  }
  let maxSum = 0;
  let tempSum = 0;

  for (let i = 0; i < num; i++) {
    maxSum += arr[i];
  }
  tempSum = maxSum;

  for (let i = num; i < arr.length; i++) {
    tempSum = tempSum - arr[i - num] + arr[i];
    maxSum = Math.max(maxSum, tempSum);
  }

  return maxSum;
}



