// const express = require('express');
import express from "express"; // ES6 syntax

const app = express()
const port = 3000;

app.get("/menu/vegetarian", (req, res) => {
    res.send("greetings!!!");
});

app.listen(port, () => {
    console.log(`Menu server listening at http://localhost:${port}`);
});

console.log("end of script");