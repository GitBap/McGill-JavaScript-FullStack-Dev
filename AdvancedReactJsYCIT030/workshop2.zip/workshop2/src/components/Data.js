import React from "react";

const bizcards = [
  {
    name: "Oli Baptiste",
    position: "Contractor",
    email: "myfakeemail@gmail.com",
    tel: "012-345-678",
    photo:
      "https://banffventureforum.com/wp-content/uploads/2019/08/no-photo-icon-22.png",
    favorite: false,
  },
  {
    name: "Miles morales",
    position: "Contractor",
    email: "morales@miles.com",
    tel: "756-8548-8292",
    photo:
      "https://banffventureforum.com/wp-content/uploads/2019/08/no-photo-icon-22.png",
    favorite: false,
  },
  {
    name: "Thor Odinson",
    position: "Contractor",
    email: "odinson@thor.com",
    tel: "201-1121-0896",
    photo:
      "https://banffventureforum.com/wp-content/uploads/2019/08/no-photo-icon-22.png",
    favorite: false,
  },
  {
    name: "Cristiano Ronaldo",
    position: "Contractor",
    email: "ronaldo@cristiano.com",
    tel: "007-0007-0007",
    photo:
      "https://banffventureforum.com/wp-content/uploads/2019/08/no-photo-icon-22.png",
    favorite: false,
  },
  {
    name: "Lionel Messi",
    position: "Contractor",
    email: "messi@lionel.com",
    tel: "010-0010-0010",
    photo:
      "https://banffventureforum.com/wp-content/uploads/2019/08/no-photo-icon-22.png",
    favorite: false,
  },
];
export default bizcards;
