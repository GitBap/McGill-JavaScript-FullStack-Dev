const colors = [
  "red",
  "blue",
  "green",
  "yellow",
  "crimson",
  "deeppink",
  "deepskyblue",
  "gold",
  "lightgrey",
  "pink",
  "orange",
  "mediumturquoise",
  "lemonchiffon",
  "indigo",
];

export default colors;
