const Result = (props) => {
  const { result } = props;
  return <p id="result">{result}</p>;
};

export default Result;
