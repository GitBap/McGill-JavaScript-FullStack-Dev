const Header = () => {
  return <h1>Calculate BMI</h1>;
};

export default Header;
