import React from "react";
import "./Footer.sass";

class Footer extends React.Component {
  render() {
    return (
      <footer className="footer">Assignement 01 - Olivier Baptiste</footer>
    );
  }
}

export default Footer;
